# Novel Companion Vivi

Android wrapper for the Novel Companion V7 Vivi web app.

The GitHub Actions workflow builds a debug APK automatically.

## Build
Open the Actions tab and run **Build Novel Companion Vivi APK**. After it finishes, download the artifact named **NovelCompanion-Vivi-APK**.
